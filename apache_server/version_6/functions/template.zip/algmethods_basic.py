# =================================================================================
# Name: MONASSIS Template
# Description: basic to and fro algebraic
# Author: Kosma
# Date: 9 November 2012
# =================================================================================

#
#
#
obj = random.choice(['crate','box of marbles','tin of cookies','box of chocolates','pencil case', 'shoebox'])
boxcolour = random.choice(["palegreen","palegoldenrod","lightgreen","lightblue","thistle"])
#
# Forces in question
#
Ff1 = random.randint(100,500) # Force forward 1
Ff2 = random.randint(100,500) # Force forward 1
Fb1 = -1*random.randint(100,500) # Force forward 1
Fb2 = -1*random.randint(100,500) # Force forward 1

#print Ff1,Ff2,Fb1,Fb2

F1,F2 = random.sample([Ff1,Ff2,Fb1,Fb2],2)

if F1 > 0 and F2 > 0:
  F1direction = 'right'
  F2direction = 'right'  
  direction = 'same direction'
elif F1 > 0 and F2 < 0:
  F1direction = 'right'
  F2direction = 'left'  
  direction = 'opposite direction'
elif F1 < 0 and F2 < 0:
  F1direction = 'left'
  F2direction = 'left'  
  direction = 'same direction'
elif F1 < 0 and F2 > 0:
  F2direction = 'right'
  F1direction = 'left'  
  direction = 'opposite direction'
else:
  print 'consult your doctor'
  
R = F1+F2

if R > 0:
  text = 'to the right'
elif R < 0:
  text = 'to the left'
else:
  text = 'therefore the %s does not move'%obj


# calc variables
h = 10 # height
l = 18 # length
w = 6  # width

xmin = min(-l/2,-l/2 + F1/10,-l/2 + F2/10) -5
xmax = max(l/2+w,l/2+w+F1/10,l/2+w+F2/10) + 5
ymin = -10
ymax = 25

xpix = (xmax - xmin)*4
ypix = (ymax - ymin)*4

##
## Push and pull something
##
#boy1 = names.generate_male()
#boy2 = names.generate_male()
#while boy2 == boy1: boy2 = names.generate_male()
#girl1 = names.generate_female()
#girl2 = names.generate_female()
#while girl1 == girl2: girl2 = names.generate_female()

#senarios = {
            #'car1':[boy1+' won the lottery. He has bought himself a new car, but because he is so excited he forgets to release his handbrake. The forward force of the car due to the engine is [] and the brake is pulling back with a force of []. Choosing forward as the positive direction, what is the resultant force on the car.',Ff1,Fb1],
            #'mug':[girl1+' and '+girl2+' are have ordered tea at a local coffee shop. When the waiter brings the tea, they both reach for the same cup pulling it in opposite directions. '+girl1+' pulls with [] and  '+girl2+' pulls with [].'],
            #'crate':[],
            #'cookies':['At the beach two gulls are fighting about a cookie. They are pulling in opposite directions with forces of [] and []. What is the resultant force on the cookie?'],
            #'toy':[girl1+' and '+boy2+' are five years old and fighting over a teddy bear. They pull in opposite directions with forces of [] and []. What is the resultant force on the teddy bear?']
            #'car2':["Determine the resultant force on a car if two people are pushing it forward with forces of "+textforce+" to try and jump-start it. What is the resultant vector?","The car is pushed forward with a force of"],
            #'pigs':["Determine the resultant force on a bucket if two pigs are pushing it forwards with forces of "+textforce+" as they are trying to get to their food. What is the resultant vector?","The bucket is pushed forward with a force of"],
            #'boat':["Determine the resultant force on a tanker if two tugboats are pulling it into the harbour with forces of "+textforce+". What is the resultant vector?","The tanker is pulled into the harbour with a force of"],
            #'move':["Determine the resultant force on a washing machine if two people are moving down the hall forces of "+textforce+". What is the resultant vector?","The washing machine is bring moved with a force of"],
            #'waggon':["Determine the resultant force on a waggon if two horses are pulling it forward with forces of "+textforce+". What is the resultant vector?","The waggon is being pulled forward with a force of"]}
           #}

#
#
#




