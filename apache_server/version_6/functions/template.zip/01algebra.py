# Template = 0.bbbbbbbbb type
# getting recurring decimal with only one digit recur
options = [[1,9],[2,9],[1,3],[4,9],[5,9],[2,3],[7,9],[8,9]]
choose = random.randint(0, len(options)-1)
num = options[choose][0]
denom = options[choose][1]

#getting the recurring digit
decimal = (num*10)//denom

#getting answer as string
ans = str(num) + "/" + str(denom)
