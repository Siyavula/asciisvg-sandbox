# =================================================================================
# Name: MONASSIS Template
# Description: Grade 10, Number Patterns, Basic: focus on important words and concepts.
# Author: Eric Gulbis
# Date: 18 Oct 2012
# =================================================================================


from sympy import *

#need these symbols for the area formulae
a, b, h, r, H, s, l, w = symbols('a, b, h, r, H, s, l, w')

#this dictionary is structured as:
# 'name of shape' : (Area Formula as sympy expressions, explanation for the area, rotation value for the solution diagram)
columnA = {
  "square":(b**2, "The area is just the product of the two (equal) sides.", random.randint(0,360)),
  "rectangle":(b*h, "You can see the base (b) and the height (h) labelled in the diagram.  For a rectangle these two sides must be perpendicuar.", random.randint(0,360)),
  "triangle":(Rational(1,2)*b*h, "The base (b) and the height (h) of a triangle are labelled in the picture below.  It is very important with a triangle that the base and the height are perpendicular to each other; otherwise this area formula will not give you the correct answer.", random.randint(0,360)),
  "trapezium":(Rational(1,2)*(a+b)*h, "The two parallel sides of the trapezium (a and b) must be perpendicular to the height (h) of the trapezium.", random.randint(0,360)),
  "parallelogram":(b*h, "It is very important that the base (b) and the height (h) are perpendicular to each other.  (You may notice that this is the same as the formula for the area of a rectangle.)", random.randint(0,360)),
  "circle":(pi*r**2, "The number 'r' is the radius of the circle.", random.randint(0,360))
  }
  
  
# n is the number of shapes which must be correctly matched to their formulae
n = 2

#choose FOUR of the shapes from the dictionary, but ensure that they will not include both rectangle and parallelogram (because they have the same formula).
Shapes_Chosen_Options = ["rectangle", "parallelogram"]
while ("rectangle" in Shapes_Chosen_Options) and ("parallelogram" in Shapes_Chosen_Options):
  Shapes_Chosen_Options = random.sample(columnA, n+2)

#Now select TWO shapes from the four in 'Shapes_Chosen_Options' which will be the two shapes presented in the question.
Shapes_Chosen = random.sample(Shapes_Chosen_Options, n)
shapeA = Shapes_Chosen[0]
shapeB = Shapes_Chosen[1]


#organize the correct answers: multiple choice list ('Options'), indices of the correct answers, and then make a list of the four formulae to present in the question.
Options = ('1', '2', '3', '4', '5')
indexA = Shapes_Chosen_Options.index(shapeA)
indexB = Shapes_Chosen_Options.index(shapeB)
Formula = []
for i in range(4):
  Formula.append(latex(columnA[Shapes_Chosen_Options[i]][0].factor()))
  
  
#choose between naming the figure and showing a diagram:
flipper = random.random()



flipper = 0.1


#in this case the shapes are named...
if (flipper > 0.5):
  words1 = "named"
  presentationA = shapeA
  presentationB = shapeB
#... and here the shapes are shown as figures in the question
else:
  words1 = "shown"
  presentationA = "<figure> <media> <type>text/asciisvg</type> <src>%s.ascsvg</src> <width>200px</width> <height>200px</height> </media> </figure>" %(shapeA)
  presentationB = "<figure> <media> <type>text/asciisvg</type> <src>%s.ascsvg</src> <width>200px</width> <height>200px</height> </media> </figure>" %(shapeB)

#take explanations out of the dictionary for the XML solution
explainA = columnA[Shapes_Chosen[0]][1]
explainB = columnA[Shapes_Chosen[1]][1]


















