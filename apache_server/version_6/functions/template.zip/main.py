# ===================================================================================
# Name: MONASSIS Template
# Author: Leen
# Date: 22 Nov 2012
# ===================================================================================

def fn_clean_float(a, max_decimals = 2):
	
	# ==========================================================		
	# Author: Leen Remmelzwaal
	# Date: 27th August
	# ==========================================================		
	# This function makes the following conversions:
	# 
	# 1.234 (float) -> 1.23 (float) - maximum 2 decimal places
	# 1.23 (float) 	-> 1.23 (float)
	# 1.2 (float)	-> 1.2 (float)
	# 1.0 (float) 	-> 1 (integer)
	# ==========================================================	

	if (max_decimals < 0): return a
	if (max_decimals == 0 or int(a) == a): return int(a) 

	for i in range (0, max_decimals):
		if ((10**i * a) % 1 == 0):
			return round(a, i)

	return round(a, max_decimals)

# ===================================================================================

def fn_rounde(number, decimals_places=2):

	# ==========================================================
	# Author: Kosma von Maltitz
	# Date: 25 June 2012
	# ==========================================================
	# This function makes the following conversions:
	# if number = 3.34534636e99 and decimals_places = 2 then return 3.34e99
	# ==========================================================
	return float('%.*e'%(decimals_places,number))

# ===================================================================================

# To get field strength
def fieldStrength(charge_1,distance):
	return (charge_1*(9.00e9))/(distance**2)

# To get field strength
def forceStrength(charge_1,charge_2,distance):
	return (charge_1*charge_2*(9.00e9))/(distance**2)

# ===================================================================================
# ERROR!!
# ===================================================================================

def fn_resultant_bearing(x,y):

	output = math.degrees(math.atan(y/x))

	if (x < 0 and y < 0): return output
	if (x > 0 and y < 0): return 180-abs(output)
	if (x > 0 and y > 0): return 180+abs(output)
	if (x < 0 and y > 0): return 360+output

	return output

# ===================================================================================

# Image rotate angle
rotate_angle = 0 #random.randint(0,3)*90

# Charge
charge_a = random.choice([-4,-3,-2,-1,1,2,3,4])*10**(-9);
charge_b = random.choice([-4,-3,-2,-1,1,2,3,4])*10**(-9);
charge_c = random.choice([-4,-3,-2,-1,1,2,3,4])*10**(-9);

# Signs
coeff_a = charge_a / abs(charge_a)
coeff_b = charge_b / abs(charge_b)
coeff_c = charge_c / abs(charge_c)

sign_a = (coeff_a == -1 and "-" or "+")
sign_b = (coeff_b == -1 and "-" or "+")
sign_c = (coeff_c == -1 and "-" or "+")

# Distances
distance_ab = random.randint(10,20)*0.01;
distance_bc = random.randint(10,20)*0.01;

# Force Vector
if (sign_a == sign_b): distance_vector_a = [[0,0],[0,abs(distance_ab)]]
else: distance_vector_a = [[0,0],[0,abs(distance_ab)]]
if (sign_b == sign_c): distance_vector_c = [[0,0],[abs(distance_bc),0]]
else: distance_vector_c = [[0,0],[abs(distance_bc),0]]

# Electric Field Strength
electric_field_a = fieldStrength(charge_a,distance_ab)
electric_field_c = fieldStrength(charge_c,distance_bc)

# Force
force_ab = forceStrength(charge_a,charge_b,distance_ab)
force_bc = forceStrength(charge_b,charge_c,distance_bc)

words_force_ab = (force_ab > 0 and "<emphasis>like</emphasis> charges, and therefore <latex>Q_{B}</latex> will experience a <emphasis>repulsive</emphasis> force. The force pushes <latex>Q_{B}</latex> downwards, or in the negative y-direction" or "<emphasis>unlike</emphasis> charges, and therefore <latex>Q_{B}</latex> will experience an <emphasis>attractive</emphasis> force. The force pulls <latex>Q_{B}</latex> to the upwards, in the positive y-direction") 

words_force_bc = (force_bc > 0 and "<emphasis>like</emphasis> charges, and therefore <latex>Q_{B}</latex> will experience a <emphasis>repulsive</emphasis> force. The force pushes <latex>Q_{B}</latex> to the left, or in the negative x-direction" or "<emphasis>unlike</emphasis> charges, and therefore <latex>Q_{B}</latex> will experience an <emphasis>attractive</emphasis> force. The force pulls <latex>Q_{B}</latex> to the right, in the positive x-direction") 

# Resultant
scale_factor = max(abs(force_bc),abs(force_ab))/0.2
resultant_x = (-force_bc)/scale_factor
resultant_y = (-force_ab)/scale_factor

# Force Vector
force_vector_a = [[0,0],[0,resultant_y]]
force_vector_c = [[0,0],[resultant_x ,0]]

# Resultant
resultant_magnitude = math.sqrt(force_ab**2 + force_bc**2)
resultant_bearing = fn_resultant_bearing(force_bc,force_ab)

