# ===================================================================================
# Name: MONASSIS Template - Python File 
# Author: Leen Remmelzwaal
# Date: 22 October 2012
# ===================================================================================

string_instruction = random.choice(["Calculate", "Determine", "Find"])

# ====================================================================================
# Functions
# ====================================================================================

def fn_clean_float(a, max_decimals = 2):
  
	# ==========================================================		
	# Author: Leen Remmelzwaal
	# Date: 27th August
	# ==========================================================		
	# This function makes the following conversions:
	# 
	# 1.234 (float) -> 1.23 (float) - maximum 2 decimal places
	# 1.23 (float) 	-> 1.23 (float)
	# 1.2 (float)	-> 1.2 (float)
	# 1.0 (float) 	-> 1 (integer)
	# ==========================================================	

	if (max_decimals < 0): return a
	if (max_decimals == 0 or int(a) == a): return int(a) 

	for i in range (0, max_decimals):
		if ((10**i * a) % 1 == 0):
			return round(a, i)

	return round(a, max_decimals)

# ===============================================

def fn_format_number(value):
	return str(value).replace(".",",")

# ===============================================
# Variables
# ===============================================

max_range = 5
min_range = -1 * max_range

# ===============================================
# Gradient (M)
# ===============================================

float_m = random.choice([-2,-1.5,-1,-0.5,0.5,1,1.5,2])

if (float_m > 0):
	text_opp_direction = "above"
	text_direction = "below"
else:
	text_opp_direction = "below"
	text_direction = "above"

# ===============================================
# Intercept (C)
# ===============================================

float_c = random.choice([-2,-1.5,-1,-0.5,0,0.5,1,1.5,2])

# ===============================================
# Sign (y = mx +- c)
# ===============================================

if float_c < 0:
	str_sign = ""					# Text
else:
	str_sign = "+"				# Text

# ===============================================
# Sympy
# ===============================================

sympy.var("x")
sympy_equation = float_m * x + float_c
sympy_string = sympy.latex(sympy_equation)
sympy_string = fn_format_number(sympy_string)

# ===============================================
# Point A
# ===============================================

float_Ax = random.randint(min_range,-1)
float_Ay = fn_clean_float(float_m * float_Ax + float_c)
while (float_Ay < (min_range + 1) or float_Ay > (max_range - 1)):
  # Keep point A in the diagram
  float_Ax = random.randint(min_range,-1)
  float_Ay = fn_clean_float(float_m * float_Ax + float_c)

# ===============================================
# Point B
# ===============================================

float_Bx = random.randint(1,max_range)
float_By = fn_clean_float(float_m * float_Bx + float_c)
while (float_By < (min_range + 1) or float_By > (max_range - 1)):
  # Keep point B in the diagram
  float_Bx = random.randint(1,max_range)
  float_By = fn_clean_float(float_m * float_Bx + float_c)

# ===============================================
# Select a scenario
# ===============================================

solution_i = random.randint(0,1)

# ===============================================
# Populate arrays
# ===============================================

solution_array = list([float_Bx,float_By])
label_array = ["x","y"]; label_array[solution_i] = str(fn_clean_float(solution_array[solution_i]))
name_array = ["x","y"]; name_array[solution_i] = "<number>" + str(fn_clean_float(solution_array[solution_i])) + "</number>"
input_array = ["<input/>", "<input/>"]; input_array[solution_i] = "<number>" + str(fn_clean_float(solution_array[solution_i])) + "</number>"

known_coord_name = ["x-coordinate","y-coordinate"][solution_i]
unknown_coord_name = ["x-coordinate","y-coordinate"][1-solution_i]

# ===============================================
# Populate solution variables
# ===============================================

solution_name = str(name_array[1-solution_i])
solution_value = fn_clean_float(solution_array[1-solution_i])

# ===============================================

