# Data
shape_array = ["circle", "rectangle", "square", "triangle", "parallelogram", "trapezium"]
dimension_array = ["the radius", "each side", "each side", "each side", "each side", "each side"]
colour_array = ["pink","skyblue","lightgreen","khaki", "plum"]

# ================================

# Sampling
colour_sample = random.choice(colour_array)
shape_i = random.randint(0,len(shape_array)-1)
shape_name = shape_array[shape_i]
dimension_wording = dimension_array[shape_i]

# ================================

# Scale
size_value = random.randint(2,4)    # Value of the scale
fraction_bool = random.randint(0,1)

# Smaller
if (fraction_bool == 0):
  question_scale = size_value
  question_k = str(size_value)
  question_k_latex = question_k
  question_correct = str(pow(size_value,2))
  question_correct_latex = question_correct
  size_name_array = {4:"quadrupled", 3:"tripled", 2:"doubled"}

# Larger
elif (fraction_bool == 1):
  question_scale = 1/size_value
  question_k = "1/"+str(size_value)
  question_k_latex = r"\frac{1}{"+str(size_value)+"}"
  question_correct = "1/"+str(pow(size_value,2))
  question_correct_latex = r"\frac{1}{"+str(pow(size_value,2)) + "}"
  size_name_array = {2:"halved", 3:"a third of its original size", 4:"a quarter of its original size"}

# Wording
wording_scale = size_name_array[size_value] 

# ================================

# Create a choice_array based on question_scale
choice_dict =  { \
int(100*(size_value**3)) : str(size_value**3), \
int(100*(size_value**2)) : str(size_value**2), \
int(100*(size_value*3)) : str(size_value*3), \
int(100*(size_value*2)) : str(size_value*2), \
int(100*(size_value)) : str(size_value), \
100 : "1", \
int(100*(1/(size_value))) : "1/"+str(size_value), \
int(100*(1/(size_value**2))) : "1/"+str(size_value**2), \
int(100*(1/(size_value**3))) : "1/"+str(size_value**3), \
int(100*(1/(size_value*2))) : "1/"+str(size_value*2), \
int(100*(1/(size_value*3))) : "1/"+str(size_value*3), \
}

# Create the array (sorted, largest to smallest)
choice_array = []
for i in sorted(choice_dict,reverse=True):
	if (choice_dict[i] not in choice_array):
	  choice_array.append(choice_dict[i])

# ================================

# Select a variables for the question
solution_i = choice_array.index(question_correct)

# Scale circle sizes for image
image_size_choice = [1,question_scale]
image_scale_factor = max(image_size_choice)
image_size_array = [image_size_choice[0]/image_scale_factor,image_size_choice[1]/image_scale_factor]
