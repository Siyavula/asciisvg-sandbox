# ===================================================================================
# Name: MONASSIS Template - Python File
# Calculating Trigonometric Equation from Graph (sin)
# Author: Leen Remmelzwaal
# Date: 7th May 2012
# ===================================================================================

string_instruction = random.choice(["Calculate", "Determine", "Find"])

# ===================================================================================

def fn_clean_float(a, max_decimals = 2):
	
	# ==========================================================		
	# Author: Leen Remmelzwaal
	# Date: 27th August
	# ==========================================================		
	# This function makes the following conversions:
	# 
	# 1.234 (float) -> 1.23 (float) - maximum 2 decimal places
	# 1.23 (float) 	-> 1.23 (float)
	# 1.2 (float)	-> 1.2 (float)
	# 1.0 (float) 	-> 1 (integer)
	# ==========================================================	

	if (max_decimals < 0): return a
	if (max_decimals == 0 or int(a) == a): return int(a) 

	for i in range (0, max_decimals):
		if ((10**i * a) % 1 == 0):
			return round(a, i)

	return round(a, max_decimals)

# ===================================================================================
# MAIN CODE
# ===================================================================================

number_turns = random.randint(6,13)
field_angle = random.randint(2,5)*15
b_field = 0.1 * random.randint(1,100)
radius = 0.1*random.randint(5,20)
area = math.pi*radius*radius
time = 0.1*random.randint(1,100)

flux = area * b_field * math.cos(math.radians(field_angle))		# "Change in flux" in this question

emf = -1 * number_turns * (flux) / time

# ===================================================================================
# Variable Selection
# ===================================================================================

# r, flux, B, theta 
i_unknown = random.randint(0,3)

# Dictionaries
symbol = {'r':'r','A':'A','B':r'\vec{B}','phi':r'\Delta \phi','theta':r'\theta','emf':r'\Large{\varepsilon}','N':'N','time':r'\Delta \textrm{t}'}
value = {'r':radius,'A':area,'B':b_field,'phi':flux,'theta':field_angle,'emf':emf,'N':number_turns,'time':time}
unit = {'r':'m','A':'m^2','B':'T','phi':'Wb','theta':'°','emf':'V','N':r'turns','time':'s'}
rounding = {'r':'1 decimal place','A':'1 decimal place','B':'1 decimal place','phi':'1 decimal place','theta':'the nearest degree','emf':'1 decimal place','N':'the nearest integer','time':'1 decimal place'}

# Marks
substitution_marks = 2
total_marks = 3

# Number of turns
if (i_unknown == 0):
	text_unknown = r"number of turns of wire <latex>N</latex> on the solenoid."
	key_unknown = "N"
	text_N = r"."
else:
	text_N = r" of <latex><number><valueof>fn_clean_float(number_turns)</valueof></number></latex> turns."

# Change in flux
if (i_unknown == 1):
	text_unknown = r"change in magnetic flux <latex>\Delta \phi</latex>."
	key_unknown = "phi"
	text_flux = "The magnetic flux changes uniformly"
else:
	text_flux = r"The change in magnetic flux <latex>\Delta \phi</latex> of the solenoid is <latex><unit_number><number><valueof>fn_clean_float(flux)</valueof></number><unit>Wb</unit></unit_number></latex>"

# Change in time
if (i_unknown == 2):
	text_unknown = r"time taken for the flux to change."
	key_unknown = "time"
	text_t = r"."
else:
	text_t = r"in an interval of <latex><unit_number><number><valueof>fn_clean_float(time)</valueof></number><unit>s</unit></unit_number></latex>."

# EMF
if (i_unknown == 3):
	text_unknown = r"emf <latex>\Large{\varepsilon}</latex> induced in the coil."
	key_unknown = "emf"
	text_emf = ""
	substitution_marks = 1
	total_marks = 2
else:
	text_emf = r"The emf <latex>\Large{\varepsilon}</latex> induced in the coil is <latex><unit_number><number><valueof>fn_clean_float(emf)</valueof></number><unit>V</unit></unit_number></latex>."

# Latex
latex_value = {} # Number only
latex_unitvalue = {}	# Unit + Number
latex_list = {}	# Used in list of variables

for i in value:
	if (i == key_unknown):
		latex_unitvalue[i] = latex_value[i] = symbol[i]
		latex_list[i] = "<unit>?</unit>"
	else:
		latex_value[i] = "<number>" + str(fn_clean_float(value[i],2)) + "</number>"
		latex_unitvalue[i] = "<unit_number><number>" + str(fn_clean_float(value[i],2)) + "</number><unit>"  + str(unit[i]) + "</unit></unit_number>"
		latex_list[i] = "<unit_number><number>" + str(fn_clean_float(value[i],2)) + "</number><unit>"  + str(unit[i]) + "</unit></unit_number>"

# Formulas
formula_value = {
"emf": "",
"N": latex_value['N'] + r" &amp; = - \frac {(" + latex_value['emf'] + ")(" + latex_value['time'] + ")}{" + latex_value['phi'] + r"} \\",
"phi": latex_value['phi'] + r" &amp; = - \frac {(" + latex_value['emf'] + ")(" + latex_value['time'] + ")}{" + latex_value['N'] + r"} \\",
"time": latex_value['time'] + r" &amp; = - (" + latex_value['N'] + r") \frac{" + latex_value['phi'] + "}{" + latex_value['emf'] + r"} \\" }
